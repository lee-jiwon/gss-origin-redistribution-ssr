Replication Files for ``MARGINAL TAX RATES AND INCOME: NEW TIME SERIES EVIDENCE''
by Karel Mertens and Jose Luis Montiel Olea
J OS � E L UIS M ONTIEL O LEA

December 2017

Programmed in Matlab R2017a

RUN_ALL reproduces all graphs and tables in the paper and appendices.