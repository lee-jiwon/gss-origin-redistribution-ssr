
Replicate_FIG_I_II_III
Replicate_FIG_IV
Replicate_FIG_V
Replicate_FIG_VI
Replicate_FIG_VII_left_panel
Replicate_FIG_VII_right_panel
Replicate_FIG_VIII
Replicate_FIG_IX
Replicate_FIG_X
Replicate_FIG_XI_and_XII

Replicate_Table_I
Replicate_Table_II
Replicate_Table_IV
Replicate_Table_V

APP_Replicate_FIG_BI
APP_Replicate_FIG_BII
APP_Replicate_FIG_BIII_first_row
APP_Replicate_FIG_BIII_second_row
APP_Replicate_FIG_BIII_third_row
APP_Replicate_FIG_BIV

APP_Replicate_Table_BI
APP_Replicate_Table_BII
APP_Replicate_Table_BIII
APP_Replicate_Table_BIV



