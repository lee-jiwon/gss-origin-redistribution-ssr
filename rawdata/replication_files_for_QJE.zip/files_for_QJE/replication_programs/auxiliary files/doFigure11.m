display1= cell2mat(values(SVARIV.MAP,plotdisplay));
for nvar = 1:length(display1)
                  
        f=figure;    
        box on
        hold on
            plot(0:SVARIV.irhor-1,SVARIV.irs(:,display1(nvar),shock),'-','MarkerSize',4,'LineWidth',2,'Color', [0 0 0.5]);

            
            if isempty(SVARIVci)==0
                if isempty(SVARIVci.irsH)==0
                p1=plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,display1(nvar),1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
                plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,display1(nvar),1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
                end
                if size(SVARIVci.irsH,3)>1
                p2=plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,display1(nvar),2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
                plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,display1(nvar),2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');              
                end               
            end
            axis([0 SVARIV.irhor-1 AXES(nvar,:)])
            
            hline(0,'k-')
            ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
            xl=xlabel('horizon (years)');
            if DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==1;
            yl=ylabel('percent');
            elseif DATASET.UNIT(cell2mat(values(DATASET.MAP,{plotdisplay{nvar}})))==2;
                yl=ylabel('percentage points');
            end
            set(gca,'XTick',0:1:10)

                         
            set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',16);
            
            str=strcat('figures/',name,'_',plotdisplay{nvar});
            saveas(gcf,str,'epsc');
       
           
end















