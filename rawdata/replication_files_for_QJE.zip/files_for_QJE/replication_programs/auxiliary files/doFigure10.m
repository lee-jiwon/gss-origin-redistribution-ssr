display1= cell2mat(values(SVARIV.MAP,plotdisplay));

 f=figure;    
        box on  
            subplot(2,1,1)
            hold on 
            p1=plot(0:SVARIV.irhor-1,SVARIV.irs(:,1,shock),'-','MarkerSize',4,'LineWidth',2,'Color', [0 0 0.5]);
            plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,1,1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
            plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,1,1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
            plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,1,2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
            plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,1,2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
            if isempty(ax)~=1
            axis([0 5 ax(1,1) ax(2,1)])
            end
            hline(0,'k-')
            ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{1}}))});
            xl=xlabel('horizon (years)');
            yl=ylabel('percent');
            set(gca,'XTick',0:1:10)
            set([xl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',16);

            
            subplot(2,1,2)
            hold on 
            p2=plot(0:SVARIV.irhor-1,SVARIV.irs(:,2,shock),'-','MarkerSize',4,'LineWidth',2,'Color', [0 0 0.5]);
            plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,2,1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
            plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,2,1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
            plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,2,2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
            plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,2,2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
            if isempty(ax)~=1
            axis([0 5 ax(1,2) ax(2,2)])
            end
            hline(0,'k-')
            ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{2}}))});
            xl=xlabel('horizon (years)');
            yl=ylabel('percent');
            set(gca,'XTick',0:1:10)
            set([xl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',16);
       
       
        str=strcat('figures\',name,'Tax');
        saveas(gcf,str,'epsc');
        

for nvar = 3:length(display1)
                  
        f=figure;    
        box on
        hold on 
            plot(0:SVARIV.irhor-1,SVARIV.irs(:,display1(nvar),shock),'-','MarkerSize',4,'LineWidth',2,'Color', [0 0 0.5]);
            p1=plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,display1(nvar),1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
            plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,display1(nvar),1,shock),'LineWidth',1,'Color', [0 0 0.5],'LineStyle','--');
            p2=plot(0:SVARIV.irhor-1,SVARIVci.irsH(:,display1(nvar),2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
            plot(0:SVARIV.irhor-1,SVARIVci.irsL(:,display1(nvar),2,shock),'LineWidth',1,'Color', [0.9 0 0],'LineStyle','-.');
            hline(0,'k-')
            ti=title( DATASET.FIGLABELS{cell2mat(values(DATASET.MAP,{plotdisplay{nvar}}))});
            xl=xlabel('horizon (years)');
            yl=ylabel('percent');
            set(gca,'XTick',0:1:10)
            if isempty(ax)~=1
            axis([0 5 ax(1,nvar) ax(2,nvar)])
            end
            set([xl,yl], 'FontName', 'AvantGarde','FontSize',14);
            set([ti], 'FontName', 'AvantGarde','FontSize',16);
       
 
        str=strcat('figures\',name,plotdisplay{nvar});
        saveas(gcf,str,'epsc');
           
end
