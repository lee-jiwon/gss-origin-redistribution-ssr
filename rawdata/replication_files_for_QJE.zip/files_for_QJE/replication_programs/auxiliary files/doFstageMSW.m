function fstage = doFstageMSW(LPIV)


y      = LPIV.vars(LPIV.p+1:end,:);                    % outcome variables
%if isempty(LPIV.varsy)
Y      = LPIV.vars(LPIV.p+1:end,1);                    % endogenous regressor
%else
%Y      = LPIV.varsy(LPIV.p+1:end,1);                    % endogenous regressor
%end  
X      = lagmatrix(LPIV.vars,1:LPIV.p);
X      = [X(LPIV.p+1:end,:) LPIV.DET(LPIV.p+1:end,:)]; % controls
Z      = LPIV.taxshocks(LPIV.p+1:end,:);              % instruments


eta   = y-X*(X\y);

[LPIV.T,LPIV.n] = size(y);

    XXp           = (X'*X)./LPIV.T;
    ZXp           = (Z'*X)./LPIV.T;
    M             = eye(LPIV.T)-X*((X'*X)\X');

% fstage = ((gamma1).^2)./(Omega/LPIV.T)

gamma1 = Z'*M*Y/LPIV.T;

[~,What,~] = CovAhat_Sigmahat_Gamma(LPIV.p,X(:,[end end-size(LPIV.DET,2)+1:end-1 1:LPIV.n*LPIV.p]),Z,eta',LPIV.NWlags);
Omega = What(((LPIV.n^2)*LPIV.p)+1,((LPIV.n^2)*LPIV.p)+1) ;
fstage = ((gamma1).^2)./(Omega/LPIV.T);

